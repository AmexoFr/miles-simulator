# ✈️ Miles Simulator Premium

> Découvrez la **vraie puissance** de vos miles Air France & Amex. Simulez, comparez et voyez comment vos miles valent bien plus que leur valeur de change.

![React](https://img.shields.io/badge/React-18-61DAFB?logo=react)
![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite)
![License](https://img.shields.io/badge/License-MIT-green)

## 🚀 Fonctionnalités

- **Simulateur de valeur** — Comparez la valeur de change vs la valeur réelle en Business/Première
- **18 destinations** — Filtrez par continent et classe de voyage avec prix moyens observés
- **Multiplicateur dynamique** — Visualisez comment vos miles valent x4+ leur valeur faciale
- **Offres de parrainage** — Air France (25 000 + 40 000 miles) et Amex (0€ + 80 000 pts MR)
- **Design premium** — Animations, particules, drapeaux HD Twemoji, thème dark & gold

## 📦 Installation

```bash
git clone https://github.com/VOTRE_USERNAME/miles-simulator.git
cd miles-simulator
npm install
npm run dev
```

Le site sera accessible sur `http://localhost:5173`

## 🌐 Déploiement

### Vercel (recommandé)
1. Push le repo sur GitHub
2. Connecte-le sur [vercel.com](https://vercel.com)
3. Vercel détecte Vite automatiquement → déployé en 1 min

### Netlify
1. Push le repo sur GitHub
2. Connecte-le sur [netlify.com](https://netlify.com)
3. Build command : `npm run build` / Publish directory : `dist`

## 🛠 Personnalisation

### Liens de parrainage
Dans `src/App.jsx`, remplace les liens placeholder :
```js
const afLink = "#parrainage-air-france";   // → ton lien Air France
const amexLink = "#parrainage-amex";       // → ton lien Amex
```

### Destinations
Ajoute ou modifie les destinations dans le tableau `destinations` de `src/App.jsx`.

## 📄 License

MIT
